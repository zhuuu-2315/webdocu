# Chợ Sinh Viên: Sprint 1 (Đăng ký và đăng nhập)

## Cấu trúc

```
cho-sinh-vien/
├── docker-compose.yml      # PostgreSQL cho môi trường dev
├── backend/                # Node.js + Express (API)
│   ├── sql/init.sql        # Tạo bảng users
│   └── src/
│       ├── index.js        # Khởi động server, helmet, CORS, rate limit
│       ├── db.js           # Kết nối PostgreSQL
│       ├── routes/auth.js  # /register, /login, /me
│       └── middleware/auth.js  # Kiểm tra JWT
└── frontend/               # React + Vite
    └── src/
        ├── api.js, AuthContext.jsx, App.jsx
        ├── components/     # AuthLayout, Field
        └── pages/          # Login, Register, Home
```

## Cách chạy (cần Node.js 18+ và Docker Desktop)

1. Bật database (ở thư mục gốc):
   ```
   docker compose up -d
   ```
2. Chạy backend:
   ```
   cd backend
   cp .env.example .env      # Windows: copy .env.example .env
   npm install
   npm run dev
   ```
   Sửa `JWT_SECRET` trong `.env` thành chuỗi ngẫu nhiên. Muốn test bằng Gmail thì để trống `ALLOWED_EMAIL_SUFFIX`.
3. Chạy frontend (cửa sổ terminal khác):
   ```
   cd frontend
   npm install
   npm run dev
   ```
4. Mở http://localhost:5173

## API

| Method | Đường dẫn | Mô tả | Cần token |
|---|---|---|---|
| POST | /api/auth/register | Body: fullName, email, password | Không |
| POST | /api/auth/login | Body: email, password | Không |
| GET | /api/auth/me | Lấy thông tin người dùng hiện tại | Có (Bearer) |
| GET | /api/health | Kiểm tra server | Không |

## Phần bảo mật đã làm (ghi vào báo cáo)

- Mật khẩu được băm bằng bcrypt, không lưu mật khẩu gốc
- JWT có thời hạn, kiểm tra ở middleware
- Câu lệnh SQL dùng tham số ($1, $2...) chống SQL injection
- Validate dữ liệu ở cả frontend và backend
- helmet (header bảo mật), giới hạn kích thước body, rate limit cho login/register
- Thông báo đăng nhập sai không tiết lộ email có tồn tại hay không

## Việc nên làm ở các sprint sau

- Chuyển token từ localStorage sang cookie httpOnly để giảm rủi ro XSS
- Viết unit test cho auth (Jest + Supertest) và đưa vào GitHub Actions
- Tách auth thành service riêng khi làm phần Microservices
