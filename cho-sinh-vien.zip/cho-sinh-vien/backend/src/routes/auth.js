import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import pool from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// Hash giả để thời gian phản hồi giống nhau dù email có tồn tại hay không
const DUMMY_HASH = bcrypt.hashSync('mat-khau-gia', 10);

function signToken(userId) {
  return jwt.sign({ sub: userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  });
}

function publicUser(row) {
  return { id: row.id, fullName: row.full_name, email: row.email };
}

function validateRegister({ fullName, email, password }) {
  const errors = {};
  const suffix = (process.env.ALLOWED_EMAIL_SUFFIX || '').trim().toLowerCase();

  if (fullName.length < 2 || fullName.length > 100) {
    errors.fullName = 'Họ tên phải từ 2 đến 100 ký tự';
  }
  if (!EMAIL_RE.test(email) || email.length > 255) {
    errors.email = 'Email không hợp lệ';
  } else if (suffix && !email.endsWith(suffix)) {
    errors.email = `Cần dùng email trường (đuôi ${suffix})`;
  }
  if (password.length < 8 || password.length > 72) {
    errors.password = 'Mật khẩu phải từ 8 đến 72 ký tự';
  } else if (!/[A-Za-z]/.test(password) || !/\d/.test(password)) {
    errors.password = 'Mật khẩu cần có cả chữ và số';
  }
  return errors;
}

// POST /api/auth/register
router.post('/register', async (req, res) => {
  const fullName = String(req.body.fullName ?? '').trim();
  const email = String(req.body.email ?? '').trim().toLowerCase();
  const password = String(req.body.password ?? '');

  const errors = validateRegister({ fullName, email, password });
  if (Object.keys(errors).length > 0) {
    return res.status(400).json({ message: 'Thông tin chưa hợp lệ', errors });
  }

  try {
    const passwordHash = await bcrypt.hash(password, 10);
    // Dùng tham số $1, $2, $3 để chống SQL injection
    const { rows } = await pool.query(
      `INSERT INTO users (full_name, email, password_hash)
       VALUES ($1, $2, $3)
       RETURNING id, full_name, email`,
      [fullName, email, passwordHash]
    );
    const user = rows[0];
    return res.status(201).json({ token: signToken(user.id), user: publicUser(user) });
  } catch (err) {
    if (err.code === '23505') {
      // Vi phạm UNIQUE: email đã tồn tại
      return res.status(409).json({
        message: 'Email này đã được đăng ký',
        errors: { email: 'Email này đã được đăng ký' },
      });
    }
    console.error('Lỗi đăng ký:', err);
    return res.status(500).json({ message: 'Lỗi máy chủ, vui lòng thử lại' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const email = String(req.body.email ?? '').trim().toLowerCase();
  const password = String(req.body.password ?? '');

  if (!email || !password) {
    return res.status(400).json({ message: 'Vui lòng nhập email và mật khẩu' });
  }

  try {
    const { rows } = await pool.query(
      'SELECT id, full_name, email, password_hash FROM users WHERE email = $1',
      [email]
    );
    const user = rows[0];
    const ok = await bcrypt.compare(password, user ? user.password_hash : DUMMY_HASH);

    if (!user || !ok) {
      // Cố ý không nói rõ sai email hay sai mật khẩu
      return res.status(401).json({ message: 'Email hoặc mật khẩu không đúng' });
    }
    return res.json({ token: signToken(user.id), user: publicUser(user) });
  } catch (err) {
    console.error('Lỗi đăng nhập:', err);
    return res.status(500).json({ message: 'Lỗi máy chủ, vui lòng thử lại' });
  }
});

// GET /api/auth/me  (cần token)
router.get('/me', requireAuth, async (req, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT id, full_name, email FROM users WHERE id = $1',
      [req.userId]
    );
    if (!rows[0]) {
      return res.status(401).json({ message: 'Tài khoản không còn tồn tại' });
    }
    return res.json({ user: publicUser(rows[0]) });
  } catch (err) {
    console.error('Lỗi lấy thông tin:', err);
    return res.status(500).json({ message: 'Lỗi máy chủ, vui lòng thử lại' });
  }
});

export default router;
