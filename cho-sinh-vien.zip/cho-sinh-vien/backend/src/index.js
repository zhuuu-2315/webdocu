import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import authRoutes from './routes/auth.js';

if (!process.env.JWT_SECRET) {
  console.error('Thiếu JWT_SECRET. Hãy tạo file backend/.env từ .env.example');
  process.exit(1);
}

const app = express();

app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '10kb' }));

// Giới hạn số lần thử đăng nhập/đăng ký để chống dò mật khẩu
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Bạn thử quá nhiều lần, vui lòng đợi 15 phút' },
});
app.use('/api/auth/login', authLimiter);
app.use('/api/auth/register', authLimiter);

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));
app.use('/api/auth', authRoutes);

app.use((req, res) => res.status(404).json({ message: 'Không tìm thấy đường dẫn' }));

const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`Backend chạy tại http://localhost:${port}`));
