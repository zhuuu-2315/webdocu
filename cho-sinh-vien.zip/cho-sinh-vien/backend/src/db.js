import pg from 'pg';

// DATABASE_URL được nạp từ file .env (xem index.js)
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });

export default pool;
