import jwt from 'jsonwebtoken';

// Chặn request nếu không có token hợp lệ trong header: Authorization: Bearer <token>
export function requireAuth(req, res, next) {
  const [scheme, token] = (req.headers.authorization || '').split(' ');
  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({ message: 'Bạn cần đăng nhập' });
  }
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = Number(payload.sub);
    next();
  } catch {
    return res.status(401).json({ message: 'Phiên đăng nhập đã hết hạn, hãy đăng nhập lại' });
  }
}
