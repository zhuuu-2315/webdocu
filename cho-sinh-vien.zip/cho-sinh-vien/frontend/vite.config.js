import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // Chuyển mọi request /api sang backend để không bị lỗi CORS khi dev
    proxy: { '/api': 'http://localhost:4000' },
  },
});
