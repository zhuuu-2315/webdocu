const SAMPLE_TAGS = [
  { title: 'Giáo trình Giải tích 1', price: '40.000đ' },
  { title: 'Quạt mini cho ký túc xá', price: '85.000đ' },
  { title: 'Bàn học gấp gọn', price: '120.000đ' },
];

// Khung chung cho trang đăng nhập và đăng ký
export default function AuthLayout({ title, subtitle, children, footer }) {
  return (
    <div className="auth">
      <aside className="auth-brand">
        <p className="brand-name">Chợ Sinh Viên</p>
        <div>
          <h2>Đồ dùng sinh viên, trao tay sinh viên.</h2>
          <ul className="tags">
            {SAMPLE_TAGS.map((t) => (
              <li key={t.title} className="tag">
                <span>{t.title}</span>
                <strong>{t.price}</strong>
              </li>
            ))}
          </ul>
        </div>
      </aside>

      <main className="auth-panel">
        <div className="auth-card">
          <h1>{title}</h1>
          <p className="subtitle">{subtitle}</p>
          {children}
          <p className="auth-footer">{footer}</p>
        </div>
      </main>
    </div>
  );
}
