import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import AuthLayout from '../components/AuthLayout.jsx';
import Field from '../components/Field.jsx';
import { useAuth } from '../AuthContext.jsx';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Kiểm tra nhanh ở trình duyệt; backend vẫn kiểm tra lại lần nữa
function validate({ fullName, email, password, confirm }) {
  const errors = {};
  if (fullName.trim().length < 2) errors.fullName = 'Họ tên phải từ 2 ký tự';
  if (!EMAIL_RE.test(email.trim())) errors.email = 'Email không hợp lệ';
  if (password.length < 8) errors.password = 'Mật khẩu phải từ 8 ký tự';
  else if (!/[A-Za-z]/.test(password) || !/\d/.test(password))
    errors.password = 'Mật khẩu cần có cả chữ và số';
  if (confirm !== password) errors.confirm = 'Mật khẩu nhập lại chưa khớp';
  return errors;
}

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ fullName: '', email: '', password: '', confirm: '' });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const onChange = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  async function onSubmit(e) {
    e.preventDefault();
    setFormError('');
    const found = validate(form);
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    setSubmitting(true);
    try {
      await register({
        fullName: form.fullName.trim(),
        email: form.email.trim(),
        password: form.password,
      });
      navigate('/', { replace: true });
    } catch (err) {
      const fields = err.fields || {};
      setErrors(fields);
      if (Object.keys(fields).length === 0) setFormError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <AuthLayout
      title="Tạo tài khoản"
      subtitle="Dùng email trường để người mua biết bạn là sinh viên."
      footer={<>Đã có tài khoản? <Link to="/login">Đăng nhập</Link></>}
    >
      <form onSubmit={onSubmit} noValidate>
        <Field
          label="Họ và tên"
          name="fullName"
          autoComplete="name"
          value={form.fullName}
          onChange={onChange}
          error={errors.fullName}
        />
        <Field
          label="Email trường"
          name="email"
          type="email"
          autoComplete="email"
          placeholder="ten@truong.edu.vn"
          value={form.email}
          onChange={onChange}
          error={errors.email}
        />
        <Field
          label="Mật khẩu"
          name="password"
          type="password"
          autoComplete="new-password"
          value={form.password}
          onChange={onChange}
          error={errors.password}
        />
        <Field
          label="Nhập lại mật khẩu"
          name="confirm"
          type="password"
          autoComplete="new-password"
          value={form.confirm}
          onChange={onChange}
          error={errors.confirm}
        />
        {formError && <p className="form-error" role="alert">{formError}</p>}
        <button className="btn" type="submit" disabled={submitting}>
          {submitting ? 'Đang tạo tài khoản...' : 'Tạo tài khoản'}
        </button>
      </form>
    </AuthLayout>
  );
}
