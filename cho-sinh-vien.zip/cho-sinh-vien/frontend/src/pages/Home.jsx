import { useAuth } from '../AuthContext.jsx';

// Trang tạm sau khi đăng nhập. Sprint sau sẽ thay bằng danh sách sản phẩm.
export default function Home() {
  const { user, logout } = useAuth();

  return (
    <div className="home">
      <header className="home-header">
        <span className="brand-name">Chợ Sinh Viên</span>
        <div className="home-user">
          <span>{user.fullName}</span>
          <button className="btn btn-ghost" onClick={logout}>Đăng xuất</button>
        </div>
      </header>
      <main className="home-main">
        <h1>Xin chào, {user.fullName}</h1>
        <p>Tài khoản {user.email} đã sẵn sàng. Bước tiếp theo là đăng tin bán đồ đầu tiên.</p>
      </main>
    </div>
  );
}
